
<head>
<title>Document</title>
</head>
<link rel="stylesheet" href="style/nav.css">
<nav >
  <div >
    
    <div  >
    <!-- style="background-color: #80C4E9;" -->
      <ul class="nav-links"  >
        <img src="src/download.png" alt="">
        <li class="center">
          
          
        </li><?php
include 'Data.php';
session_start();

if(isset($_SESSION['utilisateur'])){
  if($_SESSION['utilisateur']['role']=='administrateur'){
  ?>
 
   <li class="center"><a  href="Inscription.php">Ajouter Formateur</a></li>
   <li class="center"><a  href="liststar.php">Liste des clases</a></li>
   <li class="center"><a  href="excel/index.php">Imprter Stagaires</a></li>
   <li class="center"><a href="emploii.php">Importer Emploi</a></li>
   <li class="center"><a  href="absences.php">Les absences</a></li>
  <li class="center">
          <a  href="deco.php">Deconnexion</a>
        </li>
        <span href="#" style="color: rgb(0,0,78); position: relative;left: 800px;"class="nav-link active"> Welcome <?php echo $_SESSION['utilisateur']['nom_utilisateur']."!"; ?></span>
  <?php
  }else{ echo""; ?>
  <li class="center">
          <a  href="deco.php">Deconnexion</a>
          <a  href="modifAbs.php">Modifier l'absence</a>
        </li>
        <span href="#" style="color: rgb(0,0,78); position: relative;left: 800px;"class="nav-link active"> Welcome <?php echo $_SESSION['utilisateur']['nom_utilisateur']."!"; ?></span>
  
<?php
}}else{
  echo"";?>
    
        <!-- <li class="center">
          <a   href="login.php">Connexion</a>
        </li>
        <li class="center">
          <a  href="inscription.php">INSCRIPTION</a>
        </li> -->
        <?php };?>


        
        
      </form>
    </div>
  </div>
</nav>