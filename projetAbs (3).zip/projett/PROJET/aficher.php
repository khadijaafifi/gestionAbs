<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php include 'nav.php';
    session_start();
    if (!isset($_SESSION['utilisateur']) || $_SESSION['utilisateur']['role'] !== 'administrateur') {
        header("Location: login.php"); // Rediriger vers une page d'erreur si non autorisé
        exit();
    }
    $sql = "SELECT * FROM `formateur` ";
    $Formateur = $db->query($sql)->fetchAll();
     ?>

</body>
</html>