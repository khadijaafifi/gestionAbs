<?php 
include '../data.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add stagaires</title>
    <link rel="stylesheet" href="../style/index.css">
    <style>* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background-color: #f7f9fc;
}

form {
    background: #bebaba;
    padding: 30px 30px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    text-align: center;
    width: 400px;
    
}

label {
    font-size: 1.1em;
    margin-bottom: 10px;
    display: inline-block;
    color: #333;
}

input[type="file"] {
    display: block;
    margin: 15px auto;
    padding: 5px;
}

button[type="submit"] {
    background-color: #1f2348;
    color: white;
    padding: 10px 20px;
    font-size: 1em;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}

button[type="submit"]:hover {
    background-color: #232855;
}</style>
</head>
<body>
    <form action="" method="post" enctype="multipart/form-data">
        <label for="name">ADD FICHER:</label>
        <input type="file" name="excel"  required>
        <button type="submit" name="import">import</button>

        
    </form>
    <?php 
    function escapeChar($ii)
    {
        $v = "";
        $bad = [ "'" => "\'",];
        for ($i = 0; $i < strlen($ii); $i++) {
            if (isset($bad[$ii[$i]])) {
                $v = $v . $bad[$ii[$i]];
                continue;
            }
            $v = $v . $ii[$i];
        }
        return $v;
    }
    if (isset($_POST["import"])) {
        $fileName = $_FILES["excel"]["name"];
        $fileExtension = explode('.', $fileName);
        $fileExtension = strtolower (end ($fileExtension));
       
        $newFileName = date("Y.m.d") . " - " . date("h.i.sa") . "." . $fileExtension;
        
        $targetDirectory = "uploads1/" . $newFileName;
        move_uploaded_file($_FILES["excel"]["tmp_name"], $targetDirectory);
        error_reporting(0);
        ini_set('display_errors', 0);
        
        require "excelReader/excel_reader2.php";
        require "excelReader/SpreadsheetReader.php";
        $reader = new SpreadsheetReader ($targetDirectory);
        foreach($reader as $key => $row){
        
        $Groupe = escapeChar($row[0]);
        $Module = escapeChar($row[1]);
        $FOR = escapeChar($row[2]);
        
        
        
        $sql = "INSERT INTO formateur (Groupe, Module, Formateur_nom	) VALUES ('$Groupe', '$Module', '$FOR')";

         $db->query($sql);
               
        }  echo"<script>alert('done');document.location.href='';</script>";
        }?>
    
</body>
</html>