<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f0f0f0;
    }

    form {
        width: 300px;
        margin: 100px auto;
        padding: 20px;
        background-color: #fff;
        border: 1px solid #ddd;
        box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
    }

    label {
        display: block;
        margin-top: 20px;
        font-size: 16px;
        font-weight: bold;
    }

    input[type="text"], input[type="email"], input[type="password"] {
        width: 100%;
        padding: 10px;
        margin-top: 5px;
        font-size: 16px;
        border: 1px solid #ddd;
        border-radius: 5px;
        box-sizing: border-box;
    }

    input[type="submit"] {
        width: 100%;
        padding: 10px;
        margin-top: 20px;
        font-size: 16px;
        background-color: #4CAF50;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    input[type="submit"]:hover {
        background-color: #45a049;
    }

    a {
        display: block;
        margin-top: 10px;
        text-align: center;
        font-size: 14px;
        color: #4CAF50;
        text-decoration: none;
    }

    a:hover {
        text-decoration: underline;
    }
    </style>
</head>
<body>
    <form action="#" method="post">
        <label for="uti">utilisateur</label>
        <input type="text" name="Utilisateur" id="uti"><br>
        <label for="email">Email : </label>
        <input type="email" name="email" id="email"><br>
        <label for="mdp">mot de passe</label>
        <input type="password" name="mdp" id="mdp"><br>
        <label for="cmdp">Confirmer mot de passe</label>
        <input type="password" name="cmdp" id="cmdp"><br><br>
        <label>SELECT Role</label>
        <select name="role">
            <option value="administrateur" name="administrateur">administrateur</option>
            <option value="formateur" name="formateur">formateur</option>
            
        </select>
        <input type="submit" value="Enregistrer">
    </form>

    <?php 
include('Data.php');

// Vérifie si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Vérifie que les champs ne sont pas vides et que les mots de passe correspondent
    if (!empty($_POST['mdp']) && !empty($_POST['email']) && $_POST['mdp'] == $_POST['cmdp']) {
        // Récupère les données du formulaire
        $user = $_POST['Utilisateur'];
        $email = $_POST['email'];
        $mot_de_passe = hash('sha256', $_POST['mdp']); // Use SHA256 hashing to match MySQL hashing
        $role = $_POST['role'];

        // Insère les données dans la base de données
        $sql = "INSERT INTO utilisateurs (nom_utilisateur, email, mot_de_passe, role) VALUES ('$user', '$email', '$mot_de_passe', '$role')";
        $db->query($sql);

        // Affiche un message de succès et redirige
        echo "<script>alert('Inscription réussie');</script>";
        header("location:Login.php?connexion=done");
    } else {
        // Affiche un message d'erreur si les mots de passe ne correspondent pas ou si des champs sont vides
        echo "<script>alert('Les mots de passe ne correspondent pas ou des champs sont vides');</script>";
    }
}
?>

</body>
</html>