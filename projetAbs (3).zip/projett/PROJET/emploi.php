<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Importer un fichier Excel</title>
</head>
<body>
    <h1>Importer un emploi</h1>
    <form action="" method="post" enctype="multipart/form-data">
        <label for="excelFile">Choisir un fichier Excel :</label>
        <input type="file" name="excelFile" id="excelFile" accept=".xls,.xlsx" required>
        <br><br>
        <button type="submit">Importer</button>
    </form>
    <?php
   require "<excel/excelReader/excel_reader2.php";
   require "excel/excelReader/SpreadsheetReader.php";
    // Connexion à la base de données
    $dsn = "mysql:host=localhost;dbname=ofppt"; // Remplacez "emploi" par votre base de données
    $username = "root"; // Votre utilisateur MySQL
    $password = ""; // Votre mot de passe MySQL
    try {
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("Erreur de connexion : " . $e->getMessage());
    }
    
    // Vérifier si un fichier a été uploadé
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['excelFile'])) {
        $fileTmpPath = $_FILES['excelFile']['tmp_name'];
      
        $fileName = $_FILES["excel"]["name"];
        $fileExtension = explode('.', $fileName);
        $fileExtension = strtolower (end ($fileExtension));
       
        $newFileName = date("Y.m.d") . " - " . date("h.i.sa") . "." . $fileExtension;
        
        $targetDirectory = "uploads/" . $newFileName;
        move_uploaded_file($_FILES["excel"]["tmp_name"], $targetDirectory);
        error_reporting(0);
        ini_set('display_errors', 0);
    
        // Vérifier l'extension du fichier
        if (!in_array($fileExtension, ['xls', 'xlsx'])) {
            die("Format de fichier non valide. Veuillez uploader un fichier Excel (.xls ou .xlsx).");
        }
    
        try {
            $reader = new SpreadsheetReader ($targetDirectory);
            // Parcourir les lignes
            foreach ($reader as $rowIndex => $row) {
                // Ignorer la première ligne (en-têtes)
                if ($rowIndex == 0) {
                    continue;
                }
    
                // Extraction des données de la ligne
                $classe = $row[0] ?? null;
                $jour = $row[1] ?? null;
                $seance = $row[2] ?? null;
                $cellValue = $row[3] ?? null;
    
                // Diviser les données de la cellule si elles contiennent plusieurs informations
                $parts = explode(",", $cellValue);
                $module = isset($parts[0]) ? trim($parts[0]) : null;
                $salle = isset($parts[1]) ? trim($parts[1]) : null;
                $formateur = isset($parts[2]) ? trim($parts[2]) : null;
    
                // Insérer les données dans la base de données
                $stmt = $pdo->prepare("
                    INSERT INTO emploi (classe, jour, seance, module, salle, formateur) 
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$classe, $jour, $seance, $module, $salle, $formateur]);
            }
    
            echo "Importation réussie !";
    
        } catch (Exception $e) {
            die("Erreur lors de la lecture du fichier Excel : " . $e->getMessage());
        }
    } else {
        die("Aucun fichier n'a été uploadé.");
    }
?>    
</body>
</html>
