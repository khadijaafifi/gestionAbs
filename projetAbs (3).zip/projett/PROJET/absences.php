<?php
session_start();
include('Data.php');
// Vérification de l'accès
if (!isset($_SESSION['utilisateur']) || $_SESSION['utilisateur']['role'] != "administrateur") {
    die("Accès refusé !");
}

try {
    
    // Préparation de la requête SQL corrigée
    $sql = "
        SELECT 
            absences.id AS absence_id,
            stagiaires.nom, 
            stagiaires.grp
        FROM 
            absences
        JOIN 
            stagiaires ON absences.stagiaire_id = stagiaires.id
        
    ";
    $abs = $db->prepare($sql);

    // Exécution de la requête
    $abs->execute();

    // Récupération des résultats
    $absences = $abs->fetchAll(PDO::FETCH_ASSOC);
    
    // Debug : afficher les résultats de la requête
    // var_dump($absences); // Cela permet de vérifier si des résultats sont retournés
} catch (PDOException $e) {
    die("Erreur lors de la récupération des données : " . $e->getMessage());
}
?>

<!-- Affichage des données -->
<table border="4" align="center">
    <tr>
        <th>ID d'absences</th>
        <th>Nom du stagiaire absenté</th>
        <th>Nom du groupe</th>
    </tr>
    <?php if (empty($absences)): ?>
        <tr><td colspan="3">Aucune absence à afficher</td></tr>
    <?php else: ?>
        <?php foreach ($absences as $ab): ?>
            <tr>
                <td><?= htmlspecialchars($ab['absence_id']); ?></td>
                <td><?= htmlspecialchars($ab['nom']); ?></td>
                <td><?= htmlspecialchars($ab['grp']); ?></td>
            </tr>
        <?php endforeach; ?>
    <?php endif;?>
</table>
