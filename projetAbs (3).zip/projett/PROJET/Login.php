<?php
session_start();
include('Data.php'); // Ensure database connection is correctly configured

if (!empty($_POST['mot_de_passe']) && !empty($_POST['email'])) {
    // Retrieve and sanitize input
    $email = trim($_POST['email']);
    $mot_de_passe = trim($_POST['mot_de_passe']);

    // Query to fetch user data by email
    $sql = "SELECT * FROM utilisateurs WHERE email = :email";
    $stmt = $db->prepare($sql);
    $stmt->execute([':email' => $email]);
    $data = $stmt->fetch();

    // Verify the password using SHA2 hash
    if ($data && hash_equals($data['mot_de_passe'], hash('sha256', $mot_de_passe))) {
        // Password matches
        $_SESSION['utilisateur'] = $data;
        header("Location: interFace.php?login=done"); // Redirect to the interface page
        exit;
    } else {
        echo "<script>alert('Invalid email or password');</script>"; // Show error message for invalid login
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
       @import url("https://fonts.googleapis.com/css2?family=Open+Sans:wght@200;300;400;500;600;700&display=swap");

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Open Sans", sans-serif;
}

body {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    width: 100%;
    padding: 0 10px;
    /* background: url("src/nda.jpg"), #000; */
    background-color:#001F3F;
    background-position: center;
    background-size: cover;
}

.wrapper {
    width: 400px;
    border-radius: 8px;
    padding: 30px;
    text-align: center;
    border: 1px solid rgba(255, 255, 255, 0.5);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    position: relative;
    box-shadow: 0 0 20px rgba(255, 255, 255, 0.2);
    transition: box-shadow 0.3s ease, transform 0.3s ease;
}

.wrapper:hover {
    box-shadow: 0 0 30px rgba(0, 255, 255, 0.6), 0 0 60px rgba(0, 255, 255, 0.4);
    transform: scale(1.02);
}

form {
    display: flex;
    flex-direction: column;
}

h2 {
    font-size: 2rem;
    margin-bottom: 20px;
    color: #fff;
    
}
h2:hover{
    color: #00ffcc;
    transform: scale(1.02);
    transform: translateY(-20%);
}

.input-field {
    position: relative;
    border-bottom: 2px solid #ccc;
    margin: 15px 0;
}

.input-field label {
    position: absolute;
    top: 50%;
    left: 0;
    transform: translateY(-50%);
    color: #fff;
    font-size: 16px;
    pointer-events: none;
    transition: all 0.3s ease;
}

.input-field input {
    width: 100%;
    height: 40px;
    background: transparent;
    border: none;
    outline: none;
    font-size: 16px;
    color: #fff;
    transition: border-color 0.3s ease;
}

.input-field input:focus {
    border-color: #00ffcc;
}

.input-field input:focus~label,
.input-field input:valid~label {
    font-size: 0.8rem;
    top: 10px;
    transform: translateY(-120%);
    color: #00ffcc;
}

.forget {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 25px 0 35px 0;
    color: #fff;
}

#remember {
    accent-color: #fff;
}

.wrapper a {
    color: #efefef;
    text-decoration: none;
    transition: color 0.3s ease;
}

.wrapper a:hover {
    color: #00ffcc;
    text-decoration: underline;
}

button {
    background: #fff;
    color: #000;
    font-weight: 600;
    border: none;
    padding: 12px 20px;
    cursor: pointer;
    border-radius: 3px;
    font-size: 16px;
    border: 2px solid transparent;
    transition: all 0.3s ease;
}

button:hover {
    color: #fff;
    border-color: #00ffcc;
    background: rgba(255, 255, 255, 0.15);
    transform: scale(1.05);
}

.register {
    text-align: center;
    margin-top: 30px;
    color: #fff;
}

    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Login </h2>
        <form action="" method="post">
            <div class="input-field">
                <input type="email" name="email" id="email" required>
                <label for="email">Email</label>
            </div>
            <div class="input-field">
                <input type="password" name="mot_de_passe" id="mot_de_passe" required>
                <label for="mot_de_passe">Password</label>
            </div>
            <div class="forget">
                <label for="remember">
                   
                    
                </label>
                
            </div>
            <button type="submit">Login</button>
        </form>
        <div class="register">
            
        </div>
    </div>
</body>
</html>
