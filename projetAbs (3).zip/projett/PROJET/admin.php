<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>ADMIN</title>
</head>
<body>
    
    <?php
    include 'nav.php';

    if($_SESSION['utilisateur']['role']=="administrateur"){?>
    <center style="margin:100px"> Hors service </center>
    




</body>
</html>
<?php
}else{
    
    header("location:interFace.php");
}

?>