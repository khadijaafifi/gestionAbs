<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/showall.css">
    <title>Détails du Groupe</title>
</head>
<body>
    <?php 
    include 'nav.php';

    // Vérification du paramètre `grp`
    if (isset($_GET['grp']) && !empty($_GET['grp'])) {
        $grp = htmlspecialchars($_GET['grp']);

        // Récupération des stagiaires du groupe
        $sql = "SELECT * FROM stagiaires WHERE grp = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute([$grp]);
        $stagiaires = $stmt->fetchAll();

        if ($stagiaires) {
            echo "<h1>Liste des stagiaires - Groupe $grp</h1>";
            echo "<table border='1'>";
            echo "<thead>
                    <tr>
                        <th>ID</th>
                        <th>Nom & Prénom</th>
                        <th>Note</th>
                        <th>Actions</th>
                    </tr>
                  </thead>";
            echo "<tbody>";
            foreach ($stagiaires as $stagiaire) {
                echo "<tr>";
                echo "<td>{$stagiaire['id']}</td>";

                // Si le bouton "Modifier" a été cliqué pour cet ID, afficher le formulaire
                if (isset($_POST['edit']) && $_POST['edit_id'] == $stagiaire['id']) {
                    echo "<form method='post'>
                            <input type='hidden' name='update_id' value='{$stagiaire['id']}'>
                            <td><input type='text' name='nom' value='{$stagiaire['nom']}' required></td>
                            <td><input type='text' name='note' value='{$stagiaire['note']}' required></td>
                            <td>
                                <button type='submit' name='update'>Enregistrer</button>
                                <button type='submit' name='cancel'>Annuler</button>
                            </td>
                          </form>";
                } else {
                    // Afficher les données normales avec les boutons
                    echo "<td>{$stagiaire['nom']}</td>";
                    echo "<td>{$stagiaire['note']}</td>";
                    echo "<td>
                            <form style='display:inline;' method='post'>
                                <input type='hidden' name='edit_id' value='{$stagiaire['id']}'>
                                <button type='submit' name='edit'>Modifier</button>
                            </form>
                            <form style='display:inline;' method='post'>
                                <input type='hidden' name='delete_id' value='{$stagiaire['id']}'>
                                <button type='submit' name='delete'>Supprimer</button>
                            </form>
                          </td>";
                }
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
        } else {
            echo "<div class='alert alert-danger'>Aucun stagiaire trouvé pour le groupe $grp.</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Paramètre de groupe manquant.</div>";
    }

    // Traitement de la suppression
    if (isset($_POST['delete'])) {
        $delete_id = intval($_POST['delete_id']);
        $delete_sql = "DELETE FROM stagiaires WHERE id = ?";
        $delete_stmt = $db->prepare($delete_sql);
        if ($delete_stmt->execute([$delete_id])) {
            echo "<div class='alert alert-success'>Le stagiaire a été supprimé avec succès.</div>";
            // Recharger la page pour actualiser la liste
            header("Location: ".$_SERVER['PHP_SELF']."?grp=".$grp);
            exit();
        } else {
            echo "<div class='alert alert-danger'>Erreur lors de la suppression.</div>";
        }
    }

    // Traitement de la modification
    if (isset($_POST['update'])) {
        $update_id = intval($_POST['update_id']);
        $new_nom = htmlspecialchars($_POST['nom']);
        $new_note = htmlspecialchars($_POST['note']);

        $update_sql = "UPDATE stagiaires SET nom = ?, note = ? WHERE id = ?";
        $update_stmt = $db->prepare($update_sql);
        if ($update_stmt->execute([$new_nom, $new_note, $update_id])) {
            echo "<div class='alert alert-success'>Les informations ont été mises à jour avec succès.</div>";
            // Recharger la page pour actualiser la liste
            header("Location: ".$_SERVER['PHP_SELF']."?grp=".$grp);
            exit();
        } else {
            echo "<div class='alert alert-danger'>Erreur lors de la mise à jour.</div>";
        }
    }

    // Traitement de l'annulation
    if (isset($_POST['cancel'])) {
        header("Location: ".$_SERVER['PHP_SELF']."?grp=".$grp);
        exit();
    }
    ?>
</body>
</html>
