<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formateur</title>
</head>
<body>
    <?php
    
        include 'nav.php';
        if($_SESSION ['utilisateur']['role']=='formateur'){
            include 'map.php';

        }else{
            header("location:interFace.php");
        }
        

    ?>
    
</body>
</html>