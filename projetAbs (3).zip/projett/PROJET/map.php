<?php
include 'Data.php';

// Définir les plages horaires
$timeRanges = [
    ['start' => 8, 'end' => 10],
    ['start' => 10.1, 'end' => 13],
    ['start' => 13.1, 'end' => 16],
    ['start' => 16.1, 'end' => 18],
];

// Obtenir l'heure actuelle
$currentHour = date('H') + (date('i') / 60);
$currentTimeRange = '';
foreach ($timeRanges as $range) {
    if ($currentHour >= $range['start'] && $currentHour < $range['end']) {
        $currentTimeRange = "{$range['start']}h-{$range['end']}h";
        break;
    }
}

// Récupérer les groupes par année
$form = $_SESSION['utilisateur']['nom_utilisateur'];
$sql = "SELECT DISTINCT Groupe FROM formateur WHERE Formateur_nom='$form'";
$pAnne = $db->query($sql)->fetchAll();
// Initialisation
$stagiaires = [];
$message = "";
$checkedAbsences = $_POST['absences'] ?? []; // Récupération des absences cochées

// Gestion de la soumission du formulaire principal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['absences'])) {
    $grp = $_POST['group_id'] ?? '';
    $stagiaires = [];

    foreach ($checkedAbsences as $stagiaire_id) {
        $stmt = $db->prepare("SELECT id, id_c, nom FROM stagiaires WHERE id = ?");
        $stmt->execute([$stagiaire_id]);
        $stagiaires[] = $stmt->fetch();
    }
}

// Gestion de la confirmation des absences
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_absences'])) {
    $absences = $_POST['confirm_absences'] ?? [];
    $grp = $_POST['group_id'] ?? '';
    $currentDay = date('D');

    foreach ($absences as $stagiaire_id) {
        $checkStmt = $db->prepare("SELECT COUNT(*) FROM absences WHERE stagiaire_id = ? AND day = ? AND time_range = ?");
        $checkStmt->execute([$stagiaire_id, $currentDay, $currentTimeRange]);

        if ($checkStmt->fetchColumn() == 0) {
            $insertStmt = $db->prepare("INSERT INTO absences (stagiaire_id, grp, day, time_range, is_absent) VALUES (?, ?, ?, ?, 1)");
            $insertStmt->execute([$stagiaire_id, $grp, $currentDay, $currentTimeRange]);
        }
    }
    $message = '<div class="alert alert-success">Absences confirmées et enregistrées avec succès.</div>';
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des absences</title>
    <link rel="stylesheet" href="style/showall.css">
</head>

<body>
    <div class="container">
        <?= $message ?>

        <!-- Étape 1 : Sélection du groupe -->
        <form method="post">
            <div>
                <select name="group_id" id="">
                    <option value="" hidden>Sélectionnez un groupe</option>
                    
                        <?php foreach ($pAnne as $grp): ?>
                            <option value="<?= $grp['Groupe'] ?>" <?= isset($_POST['group_id']) && $_POST['group_id'] === $grp['Groupe'] ? 'selected' : '' ?>><?= $grp['Groupe'] ?></option>
                        <?php endforeach; ?>
                    
            
                </select>
                <button type="submit">Rechercher</button>
            </div>
        </form>

        <!-- Étape 2 : Liste des stagiaires et marquage des absences -->
        <form method="post">
            <input type="hidden" name="time_range" value="<?= $currentTimeRange ?>">
            <table border="1">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nom & Prénom</th>
                        <th>Absent</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($_POST['group_id'])): ?>
                        <?php
                        $grp = $_POST['group_id'];
                        $stmt = $db->prepare("SELECT * FROM stagiaires WHERE grp = ?");
                        $stmt->execute([$grp]);
                        $stagiairesList = $stmt->fetchAll();

                        foreach ($stagiairesList as $stagiaire): ?>
                            <tr>
                                <td><?= $stagiaire['id_c'] ?></td>
                                <td><?= $stagiaire['nom'] ?></td>
                                <td><input type="checkbox" name="absences[]" value="<?= $stagiaire['id'] ?>" <?= in_array($stagiaire['id'], $checkedAbsences) ? 'checked' : '' ?>></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3">Veuillez sélectionner un groupe pour afficher les stagiaires.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <button type="submit">Afficher la confirmation</button>
        </form>

        <!-- Étape 3 : Tableau de confirmation -->
        <?php if (!empty($stagiaires)): ?>
            <form method="post">
                <input type="hidden" name="group_id" value="<?= isset($_POST['group_id']) ? htmlspecialchars($_POST['group_id']) : '' ?>">
                <input type="hidden" name="time_range" value="<?= $currentTimeRange ?>">
                <table border="1">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nom & Prénom</th>
                            <th>Confirmer</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($stagiaires as $stagiaire): ?>
                            <tr>
                                <td><?= $stagiaire['id_c'] ?></td>
                                <td><?= $stagiaire['nom'] ?></td>
                                <td><input type="checkbox" name="confirm_absences[]" value="<?= $stagiaire['id'] ?>" checked></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <button type="submit" onclick="return confirm('Voulez-vous confirmer ces absences ?')">Confirmer les absences</button>
            </form>
        <?php endif; ?>
    </div>
</body>

</html>