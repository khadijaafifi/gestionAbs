
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GESTION </title>
</head>
<body>
    <?php 
    include 'nav.php';
    
    
    
  
if(isset($_SESSION['utilisateur'])){

  if($_SESSION['utilisateur']['role']=='administrateur'){
  
    
    header("location: admin.php") ;
    }
    elseif($_SESSION['utilisateur']['role']=='formateur') { 
    header("location:formateur.php");
    }else{
      header("location:stagiaire.php");
    }
  }else{
      

      header("location:Login.php");
    
    
    ?>
        </h1>
        
            <?php };?>
    
    
</body>
</html>