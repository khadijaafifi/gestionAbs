<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/showall.css">
    <title>Gestion des Groupes</title>
</head>
<body>
    <?php 
    include 'nav.php';
    // Récupérer tous les groupes par année
    $sql = "SELECT anne, grp FROM stagiaires GROUP BY anne, grp ORDER BY anne, grp";
    $groups = $db->query($sql)->fetchAll();
    ?>
    
    <div class="container">
        <h1>Liste des Groupes</h1>
        <table border="1">
            <thead>
                <tr>
                    <th>Année</th>
                    <th>Groupe</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($groups) {
                    foreach ($groups as $group) {
                        echo "<tr>";
                        echo "<td>{$group['anne']}</td>";
                        echo "<td>{$group['grp']}</td>";
                        echo "<td>
                                <form action='group_details.php' method='get'>
                                    <input type='hidden' name='grp' value='{$group['grp']}'>
                                    <button type='submit'>Voir Groupe</button>
                                </form>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>Aucun groupe trouvé.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
