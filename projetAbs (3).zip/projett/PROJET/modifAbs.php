<?php
include 'data.php';
// Récupérer les groupes par année
session_start();
$form = $_SESSION['utilisateur']['nom_utilisateur'];
$sql = "SELECT DISTINCT Groupe FROM formateur WHERE Formateur_nom='$form'";
$pAnne = $db->query($sql)->fetchAll();
?>
<form method="post">
            <div>
                <select name="group_id" id="">
                    <option value="" hidden>Sélectionnez un groupe</option>
                    
                        <?php foreach ($pAnne as $grp): ?>
                            <option value="<?= $grp['Groupe'] ?>" <?= isset($_POST['group_id']) && $_POST['group_id'] === $grp['Groupe'] ? 'selected' : '' ?>><?= $grp['Groupe'] ?></option>
                        <?php endforeach; ?>
                    
            
                </select>
                <button type="submit">Rechercher</button>
            </div>
        </form>
<?php
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_absences'])) {
    $grp = $_POST['group_id'] ?? '';
    $updatedAbsences = $_POST['updated_absences'] ?? [];

    try {
        $resetStmt = $db->prepare("DELETE FROM absences WHERE grp = ?");
        $resetStmt->execute([$grp]);

        foreach ($updatedAbsences as $stagiaire_id) {
            $currentDay = date('D');
            $currentTimeRange = $_POST['time_range'];
            $insertStmt = $db->prepare("INSERT INTO absences (stagiaire_id, grp, day, time_range, is_absent) VALUES (?, ?, ?, ?, 1)");
            $insertStmt->execute([$stagiaire_id, $grp, $currentDay, $currentTimeRange]);
        }

        $message = '<div class="alert alert-success">Modifications enregistrées avec succès.</div>';
    } catch (PDOException $e) {
        $message = '<div class="alert alert-danger">Erreur lors de la modification : ' . htmlspecialchars($e->getMessage()) . '</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier les absences</title>
    <link rel="stylesheet" href="style/showall.css">
</head>

<body>
    <div class="container">
        <?= $message ?>

        <h2>Modifier les absences confirmées</h2>
        <form method="post">
            <input type="hidden" name="group_id" value="<?= htmlspecialchars($_POST['group_id'] ?? '') ?>">
            <input type="hidden" name="time_range" value="<?= htmlspecialchars($_POST['time_range'] ?? '') ?>">
            <table border="1">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nom & Prénom</th>
                        <th>Absent</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (!empty($_POST['group_id'])) {
                        $grp = $_POST['group_id'];
                        $confirmedStmt = $db->prepare("SELECT stagiaires.id, stagiaires.id_c, stagiaires.nom FROM stagiaires JOIN absences ON stagiaires.id = absences.stagiaire_id WHERE absences.grp = ?");
                        $confirmedStmt->execute([$grp]);
                        $confirmedAbsences = $confirmedStmt->fetchAll();

                        foreach ($confirmedAbsences as $absence): ?>
                            <tr>
                                <td><?= $absence['id_c'] ?></td>
                                <td><?= $absence['nom'] ?></td>
                                <td><input type="checkbox" name="updated_absences[]" value="<?= $absence['id'] ?>" checked></td>
                            </tr>
                        <?php endforeach;
                    } else {
                        echo '<tr><td colspan="3">Veuillez sélectionner un groupe pour afficher les absences confirmées.</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
            <button type="submit" name="update_absences">Enregistrer les modifications</button>
        </form>
    </div>
</body>

</html>
