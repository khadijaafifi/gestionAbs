<?php
session_start();
include('Data.php');

// Simuler un utilisateur connecté (à remplacer par votre système d'authentification réel)
/*$_SESSION['utilisateur'] = [
    'nom_utilisateur' => 'Manal',
    'role' => 'stagiaire', // Assurez-vous que ce rôle est 'stagiaire' pour accéder à cet espace
    'id' => 1
];*/

// Vérifiez si l'utilisateur est un stagiaire
if (!isset($_SESSION['utilisateur']) || $_SESSION['utilisateur']['role'] !== 'stagiaire') {
    header("Location: erreur.php"); // Rediriger vers une page d'erreur si non autorisé
    exit();
}

// Récupérer les absences du stagiaire connecté
$absences = [];
try {
    // Récupérer les absences
    $stmt = $db->prepare('SELECT absences.day, absences.time_range 
                          FROM absences 
                          JOIN stagiaires ON absences.stagiaire_id = stagiaires.id 
                          WHERE stagiaires.nom = :nom');
    $stmt->execute(['nom' => $_SESSION['utilisateur']['nom_utilisateur']]);
    $absences = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Erreur lors de la récupération des données : " . $e->getMessage();
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Espace Stagiaire</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: rgb(66, 56, 255);
            color: white;
            padding: 20px;
            text-align: center;
        }
        main {
            padding: 50px;
        }
        section {
            margin-bottom: 30px;
        }
        h2 {
            color: rgb(12, 139, 35);
        }
        table {
            width: 60%;
            border-collapse: collapse;
            margin: 0 auto 20px;
        }
        table, th, td {
            border: 3px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #f4f4f9;
        }
    </style>
</head>
<body>
    <header>
        <h1>Bienvenue dans votre espace, <?php echo htmlspecialchars($_SESSION['utilisateur']['nom_utilisateur']); ?> !</h1>
        <ul>
            <a href="justification.php">justification</a>
            <a href="discipline.php">discipline</a>
            <a href="deco.php">deconexion</a>
        </ul>
    </header>
    <main>
        <center>
            <!-- Section des absences -->
            <section>
                <h2>Vos absences</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Jour</th>
                            <th>Plage horaire</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($absences)) : ?>
                            <?php foreach ($absences as $absence) : ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($absence['day']); ?></td>
                                    <td><?php echo htmlspecialchars($absence['time_range']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <tr>
                                <td colspan="2">Aucune absence enregistrée</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </section>
        </center>
    </main>
</body>
</html>
