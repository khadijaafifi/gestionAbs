<?php
session_start();

// Vérification si l'utilisateur est un stagiaire
if (!isset($_SESSION['utilisateur']) || $_SESSION['utilisateur']['role'] !== 'stagiaire') {
    header("Location: erreur.php"); // Rediriger vers une page d'erreur si non autorisé
    exit();
}

// Données simulées pour les notes de discipline (à remplacer par les données réelles de votre base)
$notes_discipline = [
    ['critere' => 'Ponctualité', 'note' => 18, 'commentaire' => 'Amélioration nécessaire pour arriver à l\'heure.'],
    ['critere' => 'Comportement', 'note' => 19, 'commentaire' => 'Comportement exemplaire dans la classe.'],
    ['critere' => 'Respect des consignes', 'note' => 20, 'commentaire' => 'Toujours respectueux des consignes données.']
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes de Discipline</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #6200ea;
            color: white;
            padding: 20px;
            text-align: center;
        }
        main {
            padding: 20px;
            max-width: 800px;
            margin: auto;
        }
        h1 {
            color: #6200ea;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f9;
        }
        .note {
            text-align: center;
            font-weight: bold;
        }
        .commentaire {
            font-style: italic;
            color: #555;
        }
    </style>
</head>
<body>
    <header>
        <h1>Vos Notes de Discipline</h1>
    </header>
    <main>
        <h2>Bienvenue, <?php echo $_SESSION['utilisateur']['nom_utilisateur']; ?> !</h2>
        <p>Voici vos notes pour les différents critères de discipline :</p>

        <table>
            <thead>
                <tr>
                    <th>Critère</th>
                    <th>Note / 10</th>
                    <th>Commentaire</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($notes_discipline as $note) : ?>
                    <tr>
                        <td><?php echo $note['critere']; ?></td>
                        <td class="note"><?php echo $note['note']; ?></td>
                        <td class="commentaire"><?php echo $note['commentaire']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>
</body>
</html>
