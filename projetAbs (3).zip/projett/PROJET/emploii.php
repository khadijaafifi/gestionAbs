<?php
// Inclure la bibliothèque SpreadsheetReader
require_once 'excel/excelReader/SpreadsheetReader.php';

// Configuration de la base de données
$host = 'localhost';
$dbname = 'ofppt'; // Nom de la base de données
$user = 'root'; // Nom d'utilisateur
$password = ''; // Mot de passe

try {
    // Connexion à la base de données
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['excel_file'])) {
        if ($_FILES['excel_file']['error'] === UPLOAD_ERR_OK) {
            $fileTmpPath = $_FILES['excel_file']['tmp_name'];
            $fileName = $_FILES['excel_file']['name'];
            $uploadDir = 'uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            $filePath = $uploadDir . basename($fileName);
            move_uploaded_file($fileTmpPath, $filePath);

            try {
                $spreadsheet = new SpreadsheetReader($filePath);
                $spreadsheet->ChangeSheet(0); // Supposons que les données sont sur la première feuille

                foreach ($spreadsheet as $rowIndex => $row) {
                    if ($rowIndex == 0) {
                        // Ignorer la première ligne si elle contient des en-têtes
                        continue;
                    }

                    // Identification des colonnes
                    $identifiant = isset($row[0]) ? trim($row[0]) : '';
                    $formateur = isset($row[1]) ? trim($row[1]) : '';
                    $module = isset($row[2]) ? trim($row[2]) : '';
                    $salle = isset($row[3]) ? trim($row[3]) : '';
                    $details = [];

                    // Extraction des colonnes supplémentaires
                    for ($i = 4; $i < count($row); $i++) {
                        if (!empty($row[$i])) {
                            $details[] = trim($row[$i]);
                        }
                    }

                    // Vérification pour corriger les colonnes fusionnées
                    if (strpos($identifiant, 'FORMATEUR') !== false) {
                        $formateur = $identifiant;
                        $identifiant = '';
                    }

                    if (strpos($identifiant, 'MODULE') !== false) {
                        $module = $identifiant;
                        $identifiant = '';
                    }

                    if (!empty($identifiant) || !empty($formateur) || !empty($module)) {
                        // Insérer les données dans la base de données
                        $stmt = $pdo->prepare("INSERT INTO emploi (identifiant, formateur, module, salle, details) VALUES (?, ?, ?, ?, ?)");
                        $stmt->execute([
                            $identifiant,
                            $formateur,
                            $module,
                            $salle,
                            json_encode($details)
                        ]);
                    }
                }

                echo "<p>Les données ont été importées correctement dans la base de données.</p>";
            } catch (Exception $e) {
                echo "Erreur lors de la lecture du fichier Excel : " . $e->getMessage();
            }
        } else {
            echo "Erreur lors du téléchargement du fichier.";
        }
    }
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Importer un fichier Excel</title>
</head>
<body>
    <h1>Importer un fichier Excel</h1>
    <form action="" method="post" enctype="multipart/form-data">
        <label for="excel_file">Choisissez un fichier Excel :</label>
        <input type="file" name="excel_file" id="excel_file" accept=".xls,.xlsx" required>
        <br><br>
        <button type="submit">Importer</button>
    </form>
</body>
</html>
