<?php
session_start();

// Vérifiez si l'utilisateur est un stagiaire
if (!isset($_SESSION['utilisateur']) || $_SESSION['utilisateur']['role'] !== 'stagiaire') {
    header("Location: erreur.php"); // Redirige si non autorisé
    exit();
}

// Traitement du formulaire
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['date'] ?? null;
    $motif = $_POST['motif'] ?? null;
    $fichier = $_FILES['justificatif'] ?? null;

    // Vérification des données
    if ($date && $motif && $fichier && $fichier['error'] === 0) {
        // Définir un chemin de stockage pour les fichiers (par exemple "uploads/")
        $uploads_dir = 'uploads/';
        if (!is_dir($uploads_dir)) {
            mkdir($uploads_dir, 0777, true);
        }

        // Générer un nom unique pour le fichier
        $fichier_nom = uniqid() . '-' . basename($fichier['name']);
        $chemin_fichier = $uploads_dir . $fichier_nom;

        // Déplacer le fichier téléchargé vers le dossier de destination
        if (move_uploaded_file($fichier['tmp_name'], $chemin_fichier)) {
            $message = "Votre justification a été soumise avec succès.";
            // Sauvegarder les informations dans une base de données (ajoutez votre logique ici)
        } else {
            $message = "Erreur lors du téléversement du fichier.";
        }
    } else {
        $message = "Veuillez remplir tous les champs et sélectionner un fichier valide.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Soumettre une justification</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #6200ea;
            color: white;
            padding: 20px;
            text-align: center;
        }
        main {
            padding: 20px;
            max-width: 600px;
            margin: auto;
        }
        form {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, textarea, button {
            width: 100%;
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            background-color: #6200ea;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #3700b3;
        }
        .message {
            margin-bottom: 20px;
            padding: 10px;
            border-radius: 5px;
            background-color: #e0ffe0;
            color: #2c662d;
        }
        .message.error {
            background-color: #ffe0e0;
            color: #662c2c;
        }
    </style>
</head>
<body>
    <header>
        <h1>Soumettre une justification</h1>
        <li><a href="stagiaire.php">Retour</a></li>

    </header>
    <main>
        <?php if ($message): ?>
            <div class="message <?php echo strpos($message, 'succès') !== false ? '' : 'error'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        <form action="justification.php" method="POST" enctype="multipart/form-data">
            <label for="date">Date de l'absence</label>
            <input type="date" id="date" name="date" required>

            <label for="motif">Motif de l'absence</label>
            <textarea id="motif" name="motif" rows="4" required></textarea>

            <label for="justificatif">Téléverser un justificatif (PDF, image, etc.)</label>
            <input type="file" id="justificatif" name="justificatif" accept=".pdf, .jpg, .jpeg, .png" required>

            <button type="submit">Soumettre</button>
        </form>
    </main>
</body>
</html>
